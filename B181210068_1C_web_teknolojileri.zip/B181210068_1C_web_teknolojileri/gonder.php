<?php
    //Öncelikle post metoduyla veri gelip gelmediğini kontrol ettik. Çünkü olmayan bir veriyi atayamayız böyle bir hatayı önlemek için önce veri gelip gelmediğini kontrol ettim.
    if($_POST)
    {
        //formda name'i isim olan kısımdan gelen veriyi (value) gelenisim değişkenine atadık. Diğerlerini de aynı şekilde atadık name'e göre.
        $gelenisim = $_POST["isim"];
        $gelenSoyisim = $_POST["soyisim"];
        $gelenCinsiyet = $_POST["cinsiyet"];
        $gelenKonu = $_POST["konum"];
        $gelenMail=$_POST["mail"];
        $gelenMesaj=$_POST["mesaj"];

        //echo komutu ile yazdırdık.
        echo "İletişim formunuzu başarıyla aldık. Bizimle iletişime geçtiğiniz için teşekkürler.";
        echo('<br>');
        echo "En kısa zamanda konuyla ilgili size dönüş yapılacaktır.";
        echo ('<br>');
        echo "İsminiz: ".$gelenisim ;
        echo('<br>');
        echo "Soyisminiz: ".$gelenSoyisim ;
        echo('<br>');
        echo "Cinsiyetiniz: ".$gelenCinsiyet;
        echo('<br>');
        echo "Konu: ".$gelenKonu ;
        echo('<br>');

        //Meslek alanını doldurmak zorunlu olmadığı için hemen gelenIs degerine yukarda atama yapamam. Önce value olup olmadığına baktım varsa gelenIs'e atadım yoksa Doldurulmadı yazdım.
        if(isset($_POST["iş"]))
        {
            $gelenIs=$_POST["iş"];
            echo "Mesleğiniz: ".$gelenIs ;
            echo('<br>');
        }
        else
        {
            echo "Mesleğiniz: Doldurulmadı";
            echo('<br>');
            #default value;
        }
        
        echo "Mail Adresiniz:" .$gelenMail;
        echo('<br>');
        echo "Mesajınız: " .$gelenMesaj;
        
     
    }

?>

