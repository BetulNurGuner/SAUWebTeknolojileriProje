function isValid(frm){
    //frm.name.value'yü kolay olması için kendi oluşturduğum değişkenlere atadım. isim,soyisim vs. formdaki name'ler.
    var g_isim=frm.isim.value;
    var g_soyisim=frm.soyisim.value;
    var g_konum=frm.konum.value;
    var g_mail=frm.mail.value;
    var g_mesaj=frm.mesaj.value;
    //mail name'li kısma girilen value'de @ işaretinin kaçıncı index'te olduğunu atpos ile aldım.
    var atpos=frm.mail.value.indexOf("@");
    //mail name'li kısma girilen value'de . işaretinin son kez girildiğinde kaçıncı indexte olduğunu tutar.
    var dotpos=frm.mail.value.lastIndexOf(".");

    
    if(g_isim==null || g_isim=="")
    {
        //girilen ismin boş olup olmadığını kontrol eder boş veya null ise uyarı verir ve false döner. Diğer girilen form alanları için de aynı şey geçerli.
        alert("İsim alanı boş bırakılamaz");
        return false;
    }

    if(g_soyisim==null || g_soyisim=="" )
    {
        alert("Soyisim alanı boş bırakılamaz");
        return false;
    }

    if(g_konum==null || g_konum=="" )
    {
        alert("Konu alanı boş bırakılamaz");
        return false;
    }

    if(g_mail==null || g_mail=="" )
    {
        alert("Mail alanı boş bırakılamaz");
        return false;
    }

    if(g_mesaj==null || g_mesaj=="" )
    {
        alert("Mesaj alanı boş bırakılamaz");
        return false;
    }

    //mail'in boş olup olmadığını yukarıda kontrol etttikten sonra if'de ilk koşulda @ işaretinin ilk index olması halini yani mail'in @ ile başlamasını gösterir.
    //2.if koşullu @'den sonra gmail vs gibi en az iki harften oluşan bir ifade gelmesi gerektiğini sonra nokta olması gerektiğini kontrol eder.
    //3.koşul .'dan sonra com vs. gibi en az 3 karakter olma durumunun doğrulugunu kontrol eder.
    if ( atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length )
    {
        alert("Geçerli email adresi girin");
        return false;
    }      
    
    else
    {
        return true;
    }

}